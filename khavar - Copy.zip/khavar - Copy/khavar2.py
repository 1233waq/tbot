import telebot
from telebot import types
from telebot.types import BotCommand, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats
import json
import re
import os
DATA_FILE = 'dranoew108.json'

if os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'r') as f:
        dra = json.load(f)
else:
    dra = {}
agh = {}
bot = telebot.TeleBot('7726422228:AAGuPFNY69BKFhz3FvObQCKcpE9Z1_5WYwE')

@bot.message_handler(commands=['add_player'])
def add_player(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.reply_to_message:
            user_id = str(message.reply_to_message.from_user.id)
            if user_id in dra:
                bot.send_message(message.chat.id, 'این کاربر به عنوان پلیر وجود دارد!!')
            else:
                test = "نام پلیر"
                dra[user_id] = {
                    'نام پلیر': test,
                    'mhb': 30,
                    'دارایی': {
                        'megdar': {
                            'چوب': {'مقدار': 0},
                            'اهن': {'مقدار': 0},
                            'sang energi':{'مقدار': 10}
                        },
                        'tolidi': {
                            'کارخانه': {
                                'لول': 1,
                                'بازدهی': 50,
                                'نوع': 'چوب',
                                'bzup': 20,
                                'update': {
                                    'nm': {
                                        'چوب': {'tedad': 30}
                                    }
                                }
                            },
                            'اهنگری': {
                                'لول': 1,
                                'بازدهی': 30,
                                'نوع': 'اهن',
                                'bzup': 30,
                                'update': {
                                    'nm': {
                                        'چوب': {'tedad': 30},
                                        'اهن': {'tedad': 20}
                                    }
                                }
                            }
                        },
                        'منبع غذایی': {
                            'غذاها': {
                                'کنسرو': {'مقدار': 50,
                                        'zr': 2},
                                'test': {'مقدار': 20,
                                        'zr': 1}
                            },
                            'تولیدی': {
                                'کارخانه کنسرو سازی': {
                                    'لول': 2,
                                    'بازدهی': 30,
                                    'نوع': 'کنسرو',
                                    'bzup': 15,
                                    'update': {
                                        'nm': {
                                            'چوب': {'tedad': 20},
                                            'اهن': {'tedad': 20}
                                        }
                                    }
                                }
                            }
                        },
                        'منابع انسانی': {
                            'نیروی انسانی': {
                                'مردم': {'mgd':50,
                                        'msr': 1,
                                        'ghn':50},
                                'دانشمند': {'mgd':5,
                                        'msr': 1,
                                        'ghn':5},
                                'مهندس': {'mgd':5,
                                        'msr': 1,
                                        'ghn':5},
                                'دکتر': {'mgd':2,
                                        'msr': 1,
                                        'ghn':2},
                                'سرباز': {'mgd':10,
                                        'msr': 1,
                                        'ghn':10}
                            },
                            'ساختمان': {
                                'تلپورتر': {
                                    'لول': 1,
                                    'بازدهی': {
                                        'مردم': {'بازده': 5,
                                                'مصرفی': 1,
                                                'bzb': 5},
                                        'دانشمند': {'بازده': 1,
                                                    'مصرفی': 1,
                                                    'bzb': 1},
                                        'مهندس': {'بازده': 1,
                                                'مصرفی': 1,
                                                'bzb': 1},
                                        'دکتر': {'بازده': 1,
                                                'مصرفی': 2,
                                                'bzb': 1},
                                        'سرباز': {'بازده': 3,
                                                'مصرفی': 1,
                                                'bzb': 3}
                                    }
                                }
                            }
                        }
                    }
                }

                with open(DATA_FILE, 'w') as json_file:
                    json.dump(dra, json_file, indent=4)
                bot.send_message(message.chat.id, f'پلیر {test} اضافه شد!')
        else:
            bot.send_message(message.chat.id, "لطفاً به یک پیام پاسخ دهید.")
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")
@bot.message_handler(commands=['load_players'])
def load_players(message):
    user_id = message.from_user.id
    user_id2 = str(message.reply_to_message.from_user.id)
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id in adl:
        try:
            with open(DATA_FILE, 'r') as json_file:
                loaded_dict = json.load(json_file)
                gph = loaded_dict[user_id2]
            bot.send_message(message.chat.id, str(gph))
        except FileNotFoundError:
            bot.send_message(message.chat.id, f"فایل {DATA_FILE} پیدا نشد.")
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")
@bot.message_handler(commands=['darai'])
def send_daraie(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.reply_to_message:
            user_id = str(message.reply_to_message.from_user.id)
        else:
            bot.send_message(message.chat.id, "لطفاً به یک پیام پاسخ دهید.")
    else:    
        user_id = str(message.from_user.id)
    if user_id in dra:
        player_data = dra[user_id]
        response_message = f"نام پلیر: {player_data['نام پلیر']}\nمحبوبیت: {player_data['mhb']}\n"
        darai = player_data['دارایی']
        for factory, details in darai['منابع انسانی']['ساختمان'].items():
            response_message += f"{factory} سطح {details['لول']}\n"
        mardom = darai['منابع انسانی'].get('نیروی انسانی', {})
        for item, val in mardom.items():
            response_message += f"{item}: {val['mgd']}\n"
        for noee, details in darai['megdar'].items():
            response_message += f"{noee} : {details['مقدار']}\n"
        ghaza = darai["منبع غذایی"].get("غذاها", {})
        for item, val in ghaza.items():
            response_message += f"{item}: {val['مقدار']}\n"
        for factory, details in darai['tolidi'].items():
            response_message += f"{factory} {details['لول']}: {details['بازدهی']} {details['نوع']}\n"
# تولیدی منبع غذایی
        ghaza_tolid = darai["منبع غذایی"].get("تولیدی", {})
        for factory, val in ghaza_tolid.items():
            response_message += f"{factory} {val['لول']}: {val['بازدهی']} {val['نوع']}\n"
        bot.send_message(message.chat.id, response_message)
        start(message)
    else:
        bot.send_message(message.chat.id, "این کاربر هنوز به عنوان پلیر اضافه نشده است.")
    

@bot.message_handler(commands=['up'])
def up(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.reply_to_message:
            user_id = str(message.reply_to_message.from_user.id)
            if user_id in dra:
                player_data = dra[user_id]
                darai = player_data.get('دارایی', {})

                if 'tolidi' not in darai or 'megdar' not in darai:
                    bot.send_message(message.chat.id, "اطلاعات تولید یا مقدار برای این کاربر ناقص است.")
                    return

                response_message = f"بروزرسانی منابع:\n"
                for tolidi_name, details in darai['tolidi'].items():
                    bazde = details.get('بازدهی', 0)
                    type_d = details.get('نوع', '')
                    if type_d in darai['megdar']:
                        darai['megdar'][type_d]['مقدار'] += bazde
                        response_message += f"{type_d} : +{bazde} (از {tolidi_name})\n"
                        with open(DATA_FILE, 'w') as json_file:
                            json.dump(dra, json_file, indent=4)
                    else:
                        response_message += f"{type_d} وجود ندارد در منابع.\n"
                for tolidi_name, details in darai['منبع غذایی']['تولیدی'].items():
                    bazde = details.get('بازدهی', 0)
                    type_d = details.get('نوع', '')
                    if type_d in darai['منبع غذایی']['غذاها']:
                        darai['منبع غذایی']['غذاها'][type_d]['مقدار'] += bazde
                        response_message += f"{type_d} : +{bazde} (از {tolidi_name})\n"
                        with open(DATA_FILE, 'w') as json_file:
                            json.dump(dra, json_file, indent=4)
                    else:
                        response_message += f"{type_d} وجود ندارد در منابع.\n"
                    for tolidi_name, details in darai['منابع انسانی']['نیروی انسانی'].items():
                        mzn = details.get('ghn', 0)
                        sgq = tolidi_name
                        details['mgd'] -= mzn
                        response_message += f" مرگ {mzn} {sgq} بر اثر گشنگی\n"
                        details['ghn'] = details['mgd']
                        with open(DATA_FILE, 'w') as json_file:
                            json.dump(dra, json_file, indent=4) 
                    bot.send_message(message.chat.id, response_message)
            else:
                bot.send_message(message.chat.id, "این کاربر هنوز به عنوان پلیر اضافه نشده است.")
        else:
            bot.send_message(message.chat.id, "لطفاً به یک پیام پاسخ دهید.")
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")
@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.add("|⬆️|-ارتقا", "|💵|-دارایی")
    bot.send_message(message.chat.id, "سلام فرمانده، چه کاری براتون انجام بدم؟", reply_markup=markup)
    bot.register_next_step_handler(message, amlll)
def amlll(message):
    user_id = str(message.from_user.id)
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    if message.text == "|⬆️|-ارتقا":
        if user_id in dra:
            player_data = dra[user_id]
            darai = player_data['دارایی']
            markupt.add("|👤|-منابع انسانی", "|🥣|-منابع غذایی", "|⛏|-منابع اقتصادی")
            bot.send_message(message.chat.id, "|❓|-لطفا بخش مورد نظر را انتخاب نمایید", reply_markup=markupt)
            bot.register_next_step_handler(message, aml)
        else:
            bot.send_message(message.chat.id, "|‼️|-شما پلیر نیستید!")
    elif message.text == "|💵|-دارایی":
        if user_id in dra:
            send_daraie(message)
        else:
            bot.send_message(message.chat.id, "|‼️|-شما پلیر نیستید!")
def aml(message):
    user_id = str(message.from_user.id)
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    if message.text == "|⛏|-منابع اقتصادی":
        if user_id in dra:
            player_data = dra[user_id]
            darai = player_data['دارایی']
        
            for metod, datails in darai['tolidi'].items():
                markupt.add(f"{metod}")
            bot.send_message(message.chat.id, "|❓|-لطفا ساختمان مورد نظر را انتخاب کنید", reply_markup=markupt)
            bot.register_next_step_handler(message, ertega2)
        else:
            bot.send_message(message.chat.id, "|‼️|-شما پلیر نیستید!")
    elif message.text == "|🥣|-منابع غذایی":
        if user_id in dra:
            player_data = dra[user_id]
            darai = player_data['دارایی']
        
            for metod, datails in darai['منبع غذایی']['تولیدی'].items():
                markupt.add(f"{metod}")
            bot.send_message(message.chat.id, "|❓|-لطفا ساختمان مورد نظر را انتخاب کنید", reply_markup=markupt)
            bot.register_next_step_handler(message, ertegaghz2)
        else:
            bot.send_message(message.chat.id, "|‼️|-شما پلیر نیستید!")
def ertega2(message):
    user_id = str(message.from_user.id)
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    player_data = dra[user_id]
    darai = player_data['دارایی']
    player_data['fa4'] = message.text
    msg = "موارد مورد نیاز برای ارتقا\n"
    for item, need in darai['tolidi'][message.text]['update']['nm'].items():
        ghz = need.get('tedad', 0)
        msg += f"{item} : {ghz}\n"
    msg += "آیا ارتقارا تایید میکنید؟"
    markupt.add("بله","خیر")
    bot.send_message(message.chat.id, msg, reply_markup=markupt)
    bot.register_next_step_handler(message, ertega)
def ertegaghz2(message):
    user_id = str(message.from_user.id)
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    player_data = dra[user_id]
    darai = player_data['دارایی']
    player_data['fa4'] = message.text
    msg = "موارد مورد نیاز برای ارتقا\n"
    for item, need in darai['منبع غذایی']['تولیدی'][message.text]['update']['nm'].items():
        ghz = need.get('tedad', 0)
        msg += f"{item} : {ghz}\n"
    msg += "آیا ارتقارا تایید میکنید؟"
    markupt.add("بله","خیر")
    bot.send_message(message.chat.id, msg, reply_markup=markupt)
    bot.register_next_step_handler(message, ertegaghz)
def ertegaghz(message):
    user_id = str(message.from_user.id)
    #skht = player_data['fa4']
    player_data = dra[user_id]
    darai = player_data['دارایی']
    can_upgrade = True
    if message.text == "بله":
        skht = player_data['fa4']  
        update_data = darai['منبع غذایی']['تولیدی'][skht]['update']['nm']
        resources = darai['megdar']
        for item, need in update_data.items():
            if item not in resources or resources[item]['مقدار'] < need['tedad']:
                can_upgrade = False
                break

        if can_upgrade:
            for item, need in update_data.items():
                resources[item]['مقدار'] -= need['tedad']
            bzup = darai['منبع غذایی']['تولیدی'][skht].get('bzup', 0)
            darai['منبع غذایی']['تولیدی'][skht]['لول'] += 1
            darai['منبع غذایی']['تولیدی'][skht]['بازدهی'] += bzup

            with open(DATA_FILE, 'w') as json_file:
                json.dump(dra, json_file, indent=4)
            bot.send_message(message.chat.id, f"|✅|-ساختمان {skht} با موفقیت ارتقا یافت!")
        else:
            bot.send_message(message.chat.id, "|‼️|-شما منابع کافی برای ارتقا ندارید.")
    else:  
        bot.send_message(message.chat.id, "|‼️|- ارتقا لغو شد")
    del player_data['fa4']
def ertega(message):
    user_id = str(message.from_user.id)
    player_data = dra[user_id]
    darai = player_data['دارایی']
    #skht = message.text
    if message.text == "بله":
        skht = player_data['fa4'] 
        if user_id not in dra:
            bot.send_message(message.chat.id, "|‼️|-شما پلیر نیستید!")
            start(message)
            return
        if skht not in darai['tolidi']:
            bot.send_message(message.chat.id, "|⚠️|-ساختمان وارد شده وجود ندارد.")
            start(message)
            return

        update_data = darai['tolidi'][skht]['update']['nm']
        resources = darai['megdar']
        can_upgrade = True

        for item, need in update_data.items():
            if item not in resources or resources[item]['مقدار'] < need['tedad']:
                can_upgrade = False
                break

        if can_upgrade:
            for item, need in update_data.items():
                resources[item]['مقدار'] -= need['tedad']
            bzup = darai['tolidi'][skht].get('bzup', 0)
            darai['tolidi'][skht]['لول'] += 1
            darai['tolidi'][skht]['بازدهی'] += bzup

            with open(DATA_FILE, 'w') as json_file:
                json.dump(dra, json_file, indent=4)
            bot.send_message(message.chat.id, f"|✅|-ساختمان {skht} با موفقیت ارتقا یافت!")
            start(message)
        else:
            bot.send_message(message.chat.id, "|‼️|-شما منابع کافی برای ارتقا ندارید.")
            start(message)
    else:  
        bot.send_message(message.chat.id, "|‼️|- ارتقا لغو شد")
    del player_data['fa4']
@bot.message_handler(commands=['afz'])
def afzodan(message):
    
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if not message.reply_to_message:
            bot.send_message(message.chat.id, "لطفاً به پیام کاربر مورد نظر پاسخ دهید.")
            return
        else:
            user_id = str(message.reply_to_message.from_user.id)
            
            markupt.add("|👤|-منابع انسانی", "|🥣|-منابع غذایی", "|⛏|-منابع اقتصادی")
            bot.send_message(message.chat.id, "|❓|-لطفا بخش مورد نظر را انتخاب نمایید", reply_markup=markupt)
            bot.register_next_step_handler(message, enttkhb)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")
def enttkhb(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.text == "|⛏|-منابع اقتصادی":  
            bot.send_message(message.chat.id, 'اسم و لول و اندازه را وارد نمایید (فرمت: نام : مقدار لول: سطح)')
            bot.register_next_step_handler(message, afzd)
        elif message.text == "|🥣|-منابع غذایی":
            bot.send_message(message.chat.id, 'اسم و لول و اندازه را وارد نمایید (فرمت: نام : مقدار لول: سطح)')
            bot.register_next_step_handler(message, afzdgh)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید") 
def afzdgh(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if not message.reply_to_message:
            bot.send_message(message.chat.id, "لطفاً به پیام کاربر مورد نظر پاسخ دهید.")
            return

        user_id = str(message.reply_to_message.from_user.id)
        pattern = r"^(.*) : (\d+) (.+) لول: (\d+)\n(.*) : (\d+)\n(.*) : (\d+)\n(.*) : (\d+)\n(\d+)$"
        match = re.search(pattern, message.text)

        if match:
            skht = match.group(1).strip()
            tda = int(match.group(2))
            nao = match.group(3).strip()
            lvl = int(match.group(4))
            ert1 = match.group(5).strip()
            tda1 = int(match.group(6))
            ert2 = match.group(7).strip()
            tda2 = int(match.group(8))
            ert3 = match.group(9).strip()
            tda3 = int(match.group(10))
            bzp = int(match.group(11))
            if user_id not in dra:
                bot.send_message(message.chat.id, "این کاربر هنوز به عنوان پلیر اضافه نشده است.")
                afzdgh(message)

            dra[user_id]['دارایی']['منبع غذایی']['تولیدی'][skht] = {
                'لول': lvl,
                'بازدهی': tda,
                'نوع': nao,
                'bzup': bzp,
                'update': {
                    'nm': {
                        ert1: {'tedad': tda1},
                        ert2: {'tedad': tda2},
                        ert3: {'tedad': tda3}
                    }
                }
            }

            if nao not in dra[user_id]['دارایی']['منبع غذایی']['غذاها']:
                dra[user_id]['دارایی']['منبع غذایی']['غذاها'][nao] = {'مقدار': 0}

            with open(DATA_FILE, 'w') as json_file:
                json.dump(dra, json_file, indent=4)

            bot.send_message(message.chat.id, f'ساختمان {skht} با لول {lvl} و بازدهی {tda} از نوع {nao} اضافه شد!')
        else:
            bot.send_message(message.chat.id, "فرمت ورودی نادرست است. لطفاً دوباره امتحان کنید. \nفرمت صحیح: نام : مقدار نوع لول: سطح")
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")   
def afzd(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if not message.reply_to_message:
            bot.send_message(message.chat.id, "لطفاً به پیام کاربر مورد نظر پاسخ دهید.")
            return

        user_id = str(message.reply_to_message.from_user.id)
        pattern = r"^(.*) : (\d+) (.+) لول: (\d+)\n(.*) : (\d+)\n(.*) : (\d+)\n(.*) : (\d+)\n(\d+)$"
        match = re.search(pattern, message.text)

        if match:
            skht = match.group(1).strip()
            tda = int(match.group(2))
            nao = match.group(3).strip()
            lvl = int(match.group(4))
            ert1 = match.group(5).strip()
            tda1 = int(match.group(6))
            ert2 = match.group(7).strip()
            tda2 = int(match.group(8))
            ert3 = match.group(9).strip()
            tda3 = int(match.group(10))
            bzp = int(match.group(11))
            if user_id not in dra:
                bot.send_message(message.chat.id, "این کاربر هنوز به عنوان پلیر اضافه نشده است.")
                return

            # بررسی و ساخت ساختار مورد نیاز
            if 'دارایی' not in dra[user_id]:
                dra[user_id]['دارایی'] = {}

            if 'tolidi' not in dra[user_id]['دارایی']:
                dra[user_id]['دارایی']['tolidi'] = {}

            dra[user_id]['دارایی']['tolidi'][skht] = {
                'لول': lvl,
                'بازدهی': tda,
                'نوع': nao,
                'bzup': bzp,
                'update': {
                    'nm': {
                        ert1: {'tedad': tda1},
                        ert2: {'tedad': tda2},
                        ert3: {'tedad': tda3}
                    }
                }
            }

            if 'megdar' not in dra[user_id]['دارایی']:
                dra[user_id]['دارایی']['megdar'] = {}

            if nao not in dra[user_id]['دارایی']['megdar']:
                dra[user_id]['دارایی']['megdar'][nao] = {'مقدار': 0}

            with open(DATA_FILE, 'w') as json_file:
                json.dump(dra, json_file, indent=4)

            bot.send_message(message.chat.id, f'ساختمان {skht} با لول {lvl} و بازدهی {tda} از نوع {nao} اضافه شد!')
        else:
            bot.send_message(message.chat.id, "فرمت ورودی نادرست است. لطفاً دوباره امتحان کنید. \nفرمت صحیح: نام : مقدار نوع لول: سطح")
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید") 
@bot.message_handler(commands=['tft'])
def tft(message):
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    user_id = message.from_user.id
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    if user_id in adl:
        bot.send_message(message.chat.id, "لطفا گروه و تلفات مورد نظر را وارد نمایید")
        bot.register_next_step_handler(message, tft2)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")
def tft2(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.text == "اتمام":
            bot.send_message(message.chat.id, "✅عملیات ثبت تلفات به اتمام رسید") 
        elif message.reply_to_message:
            user_id = str(message.reply_to_message.from_user.id)
            pattern = r"^(.*) : (\d+)$"
            match = re.search(pattern, message.text)
            if match:
                mrd = match.group(1).strip()
                tda = int(match.group(2))
                dra[user_id]['دارایی']['منابع انسانی']['نیروی انسانی'][mrd]['mgd'] -= tda
                with open(DATA_FILE, 'w') as json_file:
                    json.dump(dra, json_file, indent=4)
                bot.send_message(message.chat.id, "✅اعمال تلفات با موفقیت انجام شد") 
                tft(message)
            else:
                bot.send_message(message.chat.id, "فرمت ورودی نادرست است. لطفاً دوباره امتحان کنید.") 
        else:
            bot.send_message(message.chat.id, "لطفاً به یک پیام پاسخ دهید.")
            tft(message)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید") 
@bot.message_handler(commands=['afmnb'])
def afmnb(message):
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    user_id = message.from_user.id
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    if user_id in adl:
        markupt.add("|👤|-منابع انسانی", "|🥣|-منابع غذایی", "|⛏|-منابع اقتصادی")
        bot.send_message(message.chat.id, "|❓|-لطفا بخش مورد نظر را انتخاب نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, afmnb2)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")
def afmnb2(message):
    if message.text == "|⛏|-منابع اقتصادی":
       bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
       bot.register_next_step_handler(message, afmnbmg)
    elif message.text == "|🥣|-منابع غذایی":
       bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید")
       bot.register_next_step_handler(message, amnbgh) 
    elif message.text == "|👤|-منابع انسانی":
       bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید")
       bot.register_next_step_handler(message, amnbsn)  
def afmnbmg(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.text == "اتمام":
            bot.send_message(message.chat.id, "✅عملیات ثبت آیتم به اتمام رسید") 
        elif message.reply_to_message:
            user_id = str(message.reply_to_message.from_user.id)
            pattern = r"^(.*) : (\d+)$"
            match = re.search(pattern, message.text)
            if match:
                mnb = match.group(1).strip()
                tda = int(match.group(2))
                if mnb in dra[user_id]['دارایی']['megdar']:
                    dra[user_id]['دارایی']['megdar'][mnb]['مقدار'] += tda
                else :
                    dra[user_id]['دارایی']['megdar'][mnb] ={'مقدار': tda}
                with open(DATA_FILE, 'w') as json_file:
                    json.dump(dra, json_file, indent=4)
                bot.send_message(message.chat.id, f"✅{tda}{mnb} به دارایی اضافه شد") 
                bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
                bot.register_next_step_handler(message, afmnbmg)
            else:
                bot.send_message(message.chat.id, "فرمت ورودی نادرست است. لطفاً دوباره امتحان کنید.")
                bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
                bot.register_next_step_handler(message, afmnbmg) 
        else:
            bot.send_message(message.chat.id, "لطفاً به یک پیام پاسخ دهید.")
            bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
            bot.register_next_step_handler(message, afmnbmg)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید") 
def amnbgh(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.text == "اتمام":
            bot.send_message(message.chat.id, "✅عملیات ثبت آیتم به اتمام رسید") 
        elif message.reply_to_message:
            user_id = str(message.reply_to_message.from_user.id)
            pattern = r"^(.*) : (\d+)$"
            match = re.search(pattern, message.text)
            if match:
                mnb = match.group(1).strip()
                tda = int(match.group(2))
                if mnb in dra[user_id]['دارایی']['منبع غذایی']['غذاها']:
                    dra[user_id]['دارایی']['منبع غذایی']['غذاها'][mnb]['مقدار'] += tda
                else :
                    dra[user_id]['دارایی']['منبع غذایی']['غذاها'][mnb] ={'مقدار': tda}
                with open(DATA_FILE, 'w') as json_file:
                    json.dump(dra, json_file, indent=4)
                bot.send_message(message.chat.id, f"✅{tda}{mnb} به دارایی اضافه شد") 
                bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
                bot.register_next_step_handler(message, amnbgh)
            else:
                bot.send_message(message.chat.id, "فرمت ورودی نادرست است. لطفاً دوباره امتحان کنید.")
                bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
                bot.register_next_step_handler(message, amnbgh) 
        else:
            bot.send_message(message.chat.id, "لطفاً به یک پیام پاسخ دهید.")
            bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
            bot.register_next_step_handler(message, amnbgh)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید") 
def amnbsn(message):
    user_id2 = message.from_user.id
    
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id2 in adl:
        if message.text == "اتمام":
            bot.send_message(message.chat.id, "✅عملیات ثبت آیتم به اتمام رسید") 
        elif message.reply_to_message:
            user_id = str(message.reply_to_message.from_user.id)
            pattern = r"^(.*) : (\d+) (\d+)$"
            match = re.search(pattern, message.text)
            if match:
                mnb = match.group(1).strip()
                tda = int(match.group(2))
                tda2 = int(match.group(3))
                if mnb in dra[user_id]['دارایی']['منابع انسانی']['نیروی انسانی']:
                    dra[user_id]['دارایی']['منابع انسانی']['نیروی انسانی'][mnb]['mgd'] += tda
                    dra[user_id]['دارایی']['منابع انسانی']['نیروی انسانی'][mnb]['msr'] += tda2
                else :
                    dra[user_id]['دارایی']['منابع انسانی']['نیروی انسانی'][mnb] ={'mgd': tda}
                    dra[user_id]['دارایی']['منابع انسانی']['نیروی انسانی'][mnb] ={'msr': tda2}
                with open(DATA_FILE, 'w') as json_file:
                    json.dump(dra, json_file, indent=4)
                bot.send_message(message.chat.id, f"✅{tda}{mnb} به دارایی اضافه شد") 
                bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
                bot.register_next_step_handler(message, amnbsn)
            else:
                bot.send_message(message.chat.id, "فرمت ورودی نادرست است. لطفاً دوباره امتحان کنید.")
                bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
                bot.register_next_step_handler(message, amnbsn) 
        else:
            bot.send_message(message.chat.id, "لطفاً به یک پیام پاسخ دهید.")
            bot.send_message(message.chat.id, "|❓|-نام و مقدار  آیتم مورد نظر را وارد نمایید") 
            bot.register_next_step_handler(message, amnbsn)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید") 
@bot.message_handler(commands=['ambhf'])
def ambh(message):
    user_id = message.from_user.id
    admins = bot.get_chat_administrators(message.chat.id)
    adl = []
    for admin in admins:
            adl.append(admin.user.id)
    if user_id in adl:
        bot.send_message(message.chat.id, "|❓|-لطفا روی پلیر مورد نظر ریپلای نموده و دستور را وارد کنید") 
        bot.register_next_step_handler(message, amnbsn2)
    else:
        bot.send_message(message.chat.id, "|‼️|-شما ادمین نیستید")
def amnbsn2(message):
    if message.text == "لغو":
        bot.send_message(message.chat.id, "|‼️|-عملیات لغو شد")
    elif message.reply_to_message:
        user_id = str(message.reply_to_message.from_user.id)
        player_data = dra[user_id]
        darai = player_data['دارایی']
        pattern = r"^(.*) (\d+)$"
        match = re.search(pattern, message.text)
        if match:
            mnb = match.group(1).strip()
            tda = int(match.group(2))
            if mnb == "افزایش":
                player_data['mhb'] += tda
                with open(DATA_FILE, 'w') as json_file:
                    json.dump(dra, json_file, indent=4)
                bot.send_message(message.chat.id, f"✅محبوبیت {tda}واحد افزایش یافت") 
            elif mnb == "کاهش":
                player_data['mhb'] -= tda
                with open(DATA_FILE, 'w') as json_file:
                    json.dump(dra, json_file, indent=4)
                bot.send_message(message.chat.id, f"✅محبوبیت {tda}واحد کاهش یافت") 
    else:
        bot.send_message(message.chat.id, "|‼️|-عملیات لغو شد")
bot.set_my_commands([
    telebot.types.BotCommand("start", "استفاده از ربات"),
    telebot.types.BotCommand("up", "به روز رسانی دارایی"),
    telebot.types.BotCommand("darai", "مشاهده دارایی"),
    telebot.types.BotCommand("afz",  "افزودن منابع" ),
    #telebot.types.BotCommand("load_players", "نمایش اطلاعات پلیر"),
    telebot.types.BotCommand("tft", "اعمال تلفات"),
    telebot.types.BotCommand("ambhf", "تغییر محبوبیت"),
    telebot.types.BotCommand("afmnb", "افزودن آیتم به دارایی"),
    telebot.types.BotCommand("add_player", "افزودن پلیر")
], scope=BotCommandScopeAllGroupChats())

if __name__ == '__main__':
    bot.polling()