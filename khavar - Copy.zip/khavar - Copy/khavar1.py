import telebot
from collections import deque
from telebot import types
from Database import *
import networkx as nx
from datetime import datetime, timedelta
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
bot = telebot.TeleBot('8063288309:AAFv0wkOO8Txqc0Hppd3t76V837pX3JlOCo')
G = nx.Graph()
#graph
#a = پناهگاه پلیرا
a1="a1"
a2="a2"
a3="a3"
a4="a4"
a5="a5"
a6="a6"
a7="a7"
a8="a8"
a9="a9"
a10="a10"
a11="a11"
a12="a12"
a13="a13"
a14="a14"
a15="a15"
a16="a16"
a17="a17"
a18="a18"
a19="a19"
a20="a20"
G.add_node(a1)
G.add_node(a2)
G.add_node(a3)
G.add_node(a4)
G.add_node(a5)
G.add_node(a6)
G.add_node(a7)
G.add_node(a8)
G.add_node(a9)
G.add_node(a10)
G.add_node(a11)
G.add_node(a12)
G.add_node(a13)
G.add_node(a14)
G.add_node(a15)
G.add_node(a16)
G.add_node(a17)
G.add_node(a18)
G.add_node(a19)
G.add_node(a20)
# غار ها
g1="g1"
g2="g2"
g3="g3"
g4="g4"
g5="g5"
g6="g6"
G.add_node(g1)
G.add_node(g2)
G.add_node(g3)
G.add_node(g4)
G.add_node(g5)
G.add_node(g6)
# شهر ها و روستا ها

v1="v1"
v2="v2"
v3="v3"
v4="v4"
v5="v5"
v6="v6"
v7="v7"
v8="v8"
v9="v9"
v10="v10"
G.add_node(v1)
G.add_node(v2)
G.add_node(v3)
G.add_node(v4)
G.add_node(v5)
G.add_node(v6)
G.add_node(v7)
G.add_node(v8)
G.add_node(v9)
G.add_node(v10)
#khane ha
r1="r1"
r2="r2"
G.add_node(r1)
G.add_node(r2)
G.add_edge(a1, a2, weight=30)
G.add_edge(a2, a4, weight=50)
G.add_edge(a2, a5, weight=60)
G.add_edge(a2, g2, weight=45)
G.add_edge(a4, g2, weight=35)
G.add_edge(a4, a5, weight=40)
G.add_edge(a4, a11, weight=50)
G.add_edge(a5, g2, weight=20)
G.add_edge(a5, a6, weight=30)
G.add_edge(a5, a11, weight=60)
G.add_edge(a6, a7, weight=30)
G.add_edge(a8, g3, weight=30)
G.add_edge(a8, a9, weight=40)
G.add_edge(a9, a10, weight=20)
G.add_edge(a10, a17, weight=40)
G.add_edge(a17, a16, weight=20)
G.add_edge(a15, g5, weight=35)
G.add_edge(a15, a14, weight=25)
G.add_edge(a14, g5, weight=20)
G.add_edge(a13, a12, weight=30)
G.add_edge(a12, a11, weight=25)
G.add_edge(a18, g4, weight=15)
G.add_edge(a18, a19, weight=20)
G.add_edge(a18, a20, weight=35)
G.add_edge(a19, a20, weight=30)
G.add_edge(a19, g4, weight=25)
G.add_edge(a20, g4, weight=40)
G.add_edge(v1, v4, weight=20)
G.add_edge(v1, v2, weight=25)
G.add_edge(v1, v3, weight=35)
G.add_edge(r1, r2, weight=10)
def bfs(graph, start, goal):
    visited = set()
    queue = deque([start])
    
    while queue:
        current = queue.popleft()
        
        if current == goal:
            return True
        
        if current not in visited:
            visited.add(current)
            queue.extend(neighbor for neighbor in graph.neighbors(current) if neighbor not in visited)
            return False
# متغیرهای سراسری
namee = ""
name = 11
mbda = ""
magsd = ""
mbda2 = ""
magsd2 = ""
zaman = ""
zaman2 = ""
amrt = ""
noae = ""
noae4=""
name1 = ""
name2 = ""
name22 = ""
noae1 = ""
noae2 = ""
amar = ""
amar1 = ""
amar3 = ""
tre = ""
call=""
chat = ""
CHANNEL_ID_1 = '@retesw4'
CHANNEL_ID_2 = '@mmmdder'
CHANNEL_ID_3 = '@tre23ue'
entm = {}
@bot.message_handler(commands=['start'])
def shoro(message):
    user_id = str(message.from_user.id)
    if user_id in user_data:
        ppname(message)
    else :
        bot.reply_to(message, '|👩‍💼|-سلام فرمانده من دستیار شخصی شما هستم لطفا اسمتون رو به من بدین')
        bot.register_next_step_handler(message, ppnamer)
def ppnamer(message):
    user_id = str(message.from_user.id)
    global chat
    chat = message.chat.id
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    
    # افزودن دکمه‌ها
    markupt.add('خير', 'بله')
    user_name = message.text
    entm = user_id
    user_temp_data[user_id]= user_name
    bot.send_message(message.chat.id, "آیا نام خود را تایید می کنید؟", reply_markup= markupt)
    bot.register_next_step_handler(message, handle_query)
def handle_query(message,):
    user_id = str(message.from_user.id)
    if message.text == 'خير':
        bot.send_message(chat, "✅ عملیات لغو شد\n ‼️درصورت تمایل برای انتخاب مجدد اسم ربات را دوباره استارت کنید")
        del user_temp_data[user_id]
    if message.text == 'بله':
        user_data[user_id] = user_temp_data[user_id]
        with open(DATA_FILE, 'w') as f:
            json.dump(user_data, f)
        bot.send_message(chat,"✅ نام شما با موفقیت ذخیره شد")
        del user_temp_data[user_id]
        ppname(message)
def ppname(message):
    user_id = str(message.from_user.id)
    global name
    name = message.from_user.first_name
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)

    markup.add("|♦️|-لشکرکشی", "|⚔|-دستور حمله", "|🗡|-دستور محاصره", "|♣️|-توییتر", "|🏕|-اکتشاف", "|🗺|-نقشه")
    bot.send_message(message.chat.id, f"|👩‍💻|-سلام فرمانده «{user_data[user_id]}» دوست دارید چه کاری براتون انجام بدم؟", reply_markup=markup)
    bot.register_next_step_handler(message, handle_query)
def ppname2(message):
    user_id = str(message.from_user.id)
    global name
    name = message.from_user.first_name
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)

    markup.add("|♦️|-لشکرکشی", "|⚔|-دستور حمله", "|🗡|-دستور محاصره", "|♣️|-توییتر", "|🏕|-اکتشاف", "|🗺|-نقشه")
    bot.send_message(message.chat.id, f"|👩‍💻|- دستور بعدی شما چیه فرمانده «{user_data[user_id]}»؟", reply_markup=markup)
    bot.register_next_step_handler(message, handle_query)
def handle_query(message):
    user_id = str(message.from_user.id)
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)   
    markupt.add("زمینی", "دریایی","هوایی", "🔁 بازگشت به منو" )
    if message.text == '|♦️|-لشکرکشی':
          # استفاده از متغیر سراسری
        bot.send_message(message.chat.id, "لطفا نوع لشکرکشی را وارد کنید", reply_markup= markupt)
        bot.register_next_step_handler(message, ppnoa)
    elif message.text == '|⚔|-دستور حمله':
        bot.send_message(message.chat.id, "لطفا نوع حمله را وارد کنید", reply_markup= markupt )
        bot.register_next_step_handler(message,ppnw)
    elif message.text == '|🗡|-دستور محاصره':
        bot.send_message(message.chat.id, "لطفا نوع محاصره را وارد کنید", reply_markup= markupt)
        bot.register_next_step_handler(message, ppnwe)
    elif message.text == '|♣️|-توییتر':
        markuptt2 = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markuptt2.add("🔁 بازگشت به منو" )
        bot.send_message(message.chat.id, "لطفا متن مورد نظر را وارد نمایید", reply_markup= markuptt2)
        bot.register_next_step_handler(message, pptte)
    elif message.text == '|🏕|-اکتشاف':
        bot.send_message(message.chat.id, "لطفا نوع اکتشاف را وارد کنید", reply_markup= markupt)
        bot.register_next_step_handler(message, ppnwet) 
    elif message.text == '|🗺|-نقشه':
        markuptt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    
    # افزودن دکمه‌ها
        markuptt.add("🔁 بازگشت به منو", "قاره ۱", "قاره ۲","قاره ۳", "نقشه جهان", "نمای کلی سیاره")
        bot.send_message(message.chat.id, "لطفا قاره مورد نظر را انتخاب نمایید", reply_markup= markuptt)
        bot.register_next_step_handler(message, ppmap)  
user_temp_data = {}  # دیکشنری موقت برای هر کاربر
def est22(message):
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)   
    markupt.add("زمینی", "دریایی","هوایی", "🔁 بازگشت به منو" )

    bot.send_message(message.chat.id, "لطفا نوع لشکرکشی را وارد کنید", reply_markup= markupt)
    bot.register_next_step_handler(message, ppnoa)

def ppnoa(message):
    user_id = message.from_user.id
    user_temp_data[user_id] = {}  # پاک کردن اطلاعات قبلی
    user_temp_data[user_id]['noae'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل",  a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)

        bot.reply_to(message, "لطفا مبدا را واردکنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmabdar)

def ppnoa223(message):
    user_id = message.from_user.id
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)
        bot.reply_to(message, "لطفا مبدا را واردکنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmabdar)

def ppmabdar(message):
    user_id = message.from_user.id
    user_temp_data[user_id]['mbda'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['noae']
        est22(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)
        bot.reply_to(message, "لطفا مقصد را وارد کنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmagsddr)
def ppmabdar2(message):
    user_id = message.from_user.id
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)
        bot.reply_to(message, "لطفا مقصد را وارد کنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmagsddr)
def ppmagsddr(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['magsd'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['mbda']
        ppnoa223(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا آمار و توضحیات لشکر خود را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, amteer)
def ppmagsddr2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
    bot.reply_to(message, "لطفا آمار و توضحیات لشکر خود را وارد نمایید", reply_markup=markupt)
    bot.register_next_step_handler(message, amteer)

def amteer(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['amrt'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['magsd']
        ppmabdar2(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add('خير', 'بله', "↪️ باز گشت به مرحله قبل")
        bot.send_message(message.chat.id, "آیا دستور لشکرکشی را تایید می کنید؟", reply_markup= markupt)
        bot.register_next_step_handler(message, ppersalll)

def ppersalll(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    javab = message.text
    d = user_temp_data.get(user_id, {})
    if message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['amrt']
        ppmagsddr2(message)
    else:
        if javab == "بله":
            if nx.has_path(G, d['mbda'], d['magsd']):
                length = nx.shortest_path_length(G, source=d['mbda'], target=d['magsd'], weight='weight')
                #new_time = datetime.now() + timedelta(minutes=int(length))
                #zaman = f"{new_time.hour:02}:{new_time.minute:02}"
                bot.send_message(CHANNEL_ID_2, f"آمار ارتش {d['noae']} «{user_data[user_id2]}»  برای لشکرکشی از منطقه «{d['mbda']}» به منطقه «{d['magsd']}»\n «{d['amrt']}»")
                if d['noae'] == "زمینی":
                    new_time = datetime.now() + timedelta(minutes=int(length))
                    zaman = f"{new_time.hour:02}:{new_time.minute:02}"
                    photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_13-06-27.jpg')
                    caption = f"|🔱|-ارتش زمینی «{user_data[user_id2]}» از «{d['mbda']}» به طرف «{d['magsd']}» حرکت کردند \n|⏳|-زمان رسیدن: {zaman}"
                elif d['noae'] == "دریایی":
                    new_time = datetime.now() + timedelta(minutes=(int(length)/2))
                    zaman = f"{new_time.hour:02}:{new_time.minute:02}"
                    photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_12-01-26.jpg')
                    caption = f"|⚓️|-ارتش دریایی «{user_data[user_id2]}» از «{d['mbda']}» به طرف «{d['magsd']}» حرکت کردند \n|⏳|-زمان رسیدن: {zaman}"
                elif d['noae'] == "هوایی":
                    new_time = datetime.now() + timedelta(minutes=(int(length)/3))
                    zaman = f"{new_time.hour:02}:{new_time.minute:02}"
                    photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-05_21-54-20.jpg')
                    caption = f"|🛰|-ارتش هوایی «{user_data[user_id2]}» از «{d['mbda']}» به طرف «{d['magsd']}» حرکت کردند \n|⏳|-زمان رسیدن: {zaman}"
                else:
                    bot.send_message(message.chat.id, "نوع نیرو نامشخص است.")
                    del user_temp_data[user_id]
                    return

                with open(photo_path, 'rb') as photo:
                    bot.send_photo(CHANNEL_ID_1, photo, caption=caption)
                bot.send_message(message.chat.id, "✅ دستور لشکرکشی با موفقیت ارسال شد")
                del user_temp_data[user_id]
                ppname2(message)
            else:
                bot.send_message(message.chat.id , "|‼️|-مسیری برای انتخاب شما وجود ندارد لطفا دوباره انتخاب نمایید")
                del user_temp_data[user_id]['mbda']
                del user_temp_data[user_id]['magsd']
                del user_temp_data[user_id]['amrt']
                ppnoa223(message)
        elif javab == "خیر":
            bot.send_message(message.chat.id, "✅ دستور لشکرکشی لغو شد")
            del user_temp_data[user_id]
            ppname2(message)
def aqws2(message):
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)   
    markupt.add("زمینی", "دریایی","هوایی", "🔁 بازگشت به منو" )
    bot.send_message(message.chat.id, "لطفا نوع حمله را وارد کنید", reply_markup= markupt )
    bot.register_next_step_handler(message,ppnw)
def ppnw(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id] = {}  # پاکسازی اطلاعات قبلی

    user_temp_data[user_id]['noae1'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا نام منطقه مورد نظر را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmnt)
def ppnwe22(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا نام منطقه مورد نظر را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmnt)
def ppmnt(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['name1'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['noae1']
        aqws2(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا آمار ارتش خود را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, pptaid)
def ppmntw2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا آمار ارتش خود را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, pptaid)
def pptaid(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['amar'] = message.text

    d = user_temp_data[user_id]
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['name1']
        ppnwe22(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add('خير', 'بله', "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "آیا دستور حمله را تایید می‌کنید؟", reply_markup=markupt)
        bot.register_next_step_handler(message, ppersal)

def ppersal(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    javab = message.text
    d = user_temp_data.get(user_id, {})
    if message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['amar']
        ppmntw2(message)
    else:
        if javab == "بله":
            bot.send_message(CHANNEL_ID_2, f" آمار دستور حمله  ارتش {d['noae1']} «{user_data[user_id2]}» به منطقه «{d['name1']}»\n «{d['amar']}»")
            if d['noae1'] == "زمینی":
                photo_path = os.path.join(script_dir, 'picther\\ganz.jpg')
                caption = f"|⚔️|-فرمانده ارتش زمینی «{user_data[user_id2]}» دستور حمله به منطقه «{d['name1']}» را ارسال کرد\n سناریو را تا زمان تعیین شده ارسال نمایید"
            elif d['noae1'] == "دریایی":
                photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_13-06-16.jpg')
                caption = f"|🪝|-فرمانده ارتش دریایی «{user_data[user_id2]}» دستور حمله به منطقه «{d['name1']}» را ارسال کرد\n سناریو را تا زمان تعیین شده ارسال نمایید"
            elif d['noae1'] == "هوایی":
                photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_11-59-28.jpg')
                caption = f"|🛸|-فرمانده ارتش هوایی «{user_data[user_id2]}» دستور حمله به منطقه «{d['name1']}» را ارسال کرد\n سناریو را تا زمان تعیین شده ارسال نمایید"
            else:
                bot.send_message(message.chat.id, "نوع نیرو نامشخص است.")
                del user_temp_data[user_id]
                ppname2(message)
                

            with open(photo_path, 'rb') as photo:
                bot.send_photo(CHANNEL_ID_1, photo, caption=caption)
            bot.send_message(message.chat.id, "✅ دستور حمله با موفقیت ارسال شد")
            del user_temp_data[user_id]
            ppname2(message)

        elif javab == "خیر":
            bot.send_message(message.chat.id, "✅ دستور حمله لغو شد")
            del user_temp_data[user_id]
            ppname2(message)
def ngm22(message):
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)   
    markupt.add("زمینی", "دریایی","هوایی", "🔁 بازگشت به منو" )
    bot.send_message(message.chat.id, "لطفا نوع محاصره را وارد کنید", reply_markup= markupt)
    bot.register_next_step_handler(message, ppnwe)
def ppnwe(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id] = {}  # پاکسازی داده‌های قبلی این کاربر
    user_temp_data[user_id]['noae2'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا نام منطقه مورد نظر را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmnt2)
def ppnwe22e(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا نام منطقه مورد نظر را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmnt2)
def ppmnt2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['name2'] = message.text
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['noae2']
        ngm22(message)
    else:
        bot.reply_to(message, "لطفا آمار ارتش خود را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, pptaid2)
def ppmnt2wwe2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        bot.reply_to(message, "لطفا آمار ارتش خود را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, pptaid2)

def pptaid2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['amar1'] = message.text

    d = user_temp_data[user_id]
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['name2']
        ppnwe22e(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add('خير', 'بله', "↪️ باز گشت به مرحله قبل")

        bot.reply_to(message, "آیا دستور محاصره را تایید می کنید؟", reply_markup=markupt)
        bot.register_next_step_handler(message, ppersal2)

def ppersal2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    javab = message.text
    d = user_temp_data.get(user_id, {})
    if message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['amar1']
        ppmnt2wwe2(message)
    else:
        if javab == "بله":
            bot.send_message(
                CHANNEL_ID_2,
                f"آمار دستور محاصره  ارتش {d['noae2']} «{user_data[user_id2]}» به منطقه «{d['name2']}»\n «{d['amar1']}»"
            )
            if d['noae2'] == "زمینی":
                photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-04_21-35-55.jpg')
                caption = f"|⚔️|-فرمانده ارتش زمینی «{user_data[user_id2]}» دستور محاصره منطقه «{d['name2']}» را ارسال کرد\n سناریو را تا زمان تعیین شده ارسال نمایید"
            elif d['noae2'] == "دریایی":
                photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_11-57-33.jpg')
                caption = f"|🪝|-فرمانده ارتش دریایی «{user_data[user_id2]}» دستور محاصره منطقه «{d['name2']}» را ارسال کرد\n سناریو را تا زمان تعیین شده ارسال نمایید"
            elif d['noae2'] == "هوایی":
                photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_11-59-17.jpg')
                caption = f"|🛸|-فرمانده ارتش هوایی «{user_data[user_id2]}» دستور محاصره منطقه «{d['name2']}» را ارسال کرد\n سناریو را تا زمان تعیین شده ارسال نمایید"
            else:
                bot.send_message(message.chat.id, "نوع نیرو نامشخص است.")
                del user_temp_data[user_id]
                ppname2(message)

            with open(photo_path, 'rb') as photo:
                bot.send_photo(CHANNEL_ID_1, photo, caption=caption)
            bot.send_message(message.chat.id, "✅ دستور محاصره با موفقیت ارسال شد")
            del user_temp_data[user_id]
            ppname2(message)

        elif javab == "خیر":
            bot.send_message(message.chat.id, "✅ دستور محاصره لغو شد")
            del user_temp_data[user_id]
            ppname2(message)
def pptte(message):
    user_id = str(message.from_user.id)
    tre = message.text
    #entm = user_id
    user_temp_data[user_id] = tre
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
        del user_temp_data[user_id] 
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)    
        # افزودن دکمه‌ها
        markupt.add('خير', 'بله')
        bot.send_message(message.chat.id, "آیا بیانیه خود را تایید می کنید؟", reply_markup= markupt)
        bot.register_next_step_handler(message, pnm)
def pnm(message):
    user_id = str(message.from_user.id)
    jb = message.text
    if jb == 'بله':
        bot.send_message(CHANNEL_ID_3, f"بیانیه فرمانده «{user_data[user_id]}» :\n «{user_temp_data[user_id]}»")
        bot.send_message(message.chat.id, "✅ توییت شما با موفقیت ارسال شد")
        del user_temp_data[user_id]
        ppname2(message)
    elif jb == 'خير':
        bot.send_message(message.chat.id, "✅ عملیات ارسال توییت متوقف شد")
        del user_temp_data[user_id]
def ppnwet(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id] = {}
    user_temp_data[user_id]['noae4'] = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)
        bot.reply_to(message, "لطفا مبدا را واردکنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmabda)
def er23r4(message):
    markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)   
    markupt.add("زمینی", "دریایی","هوایی", "🔁 بازگشت به منو" )
    bot.send_message(message.chat.id, "لطفا نوع اکتشاف را وارد کنید", reply_markup= markupt)
    bot.register_next_step_handler(message, ppnwet)
def ppnwet24(message):
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)
        
        bot.reply_to(message, "لطفا مبدا را واردکنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmabda)

def ppmabda(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['mbda2'] = message.text
    if message.text == "🔁 بازگشت به منو":
        del  user_temp_data[user_id]['mbda2']
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['noae4']
        del user_temp_data[user_id]['mbda2']
        er23r4(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)

        bot.reply_to(message, "لطفا مقصد را وارد کنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmagsde)
def ppmabdawq2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    if message.text == "🔁 بازگشت به منو":
        del  user_temp_data[user_id]['mbda2']
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل", a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, r1, r2, v1, v2, v3, v4, g1, g2, g3, g4, g5, g6)

        bot.reply_to(message, "لطفا مقصد را وارد کنيد", reply_markup=markupt)
        bot.register_next_step_handler(message, ppmagsde)
def ppmagsde(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['magsd2'] = message.text
    if message.text == "🔁 بازگشت به منو":
        del user_temp_data[user_id]['magsd2'] 
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['mbda2']
        del user_temp_data[user_id]['magsd2']
        ppnwet24(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا آمار و توضحیات  تیم اکتشاف خود را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, amte)
def ppmagsdesdwe2(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    if message.text == "🔁 بازگشت به منو":
        del user_temp_data[user_id]['magsd2'] 
        ppname(message)
    else:
        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add("🔁 بازگشت به منو", "↪️ باز گشت به مرحله قبل")
        bot.reply_to(message, "لطفا آمار و توضحیات  تیم اکتشاف خود را وارد نمایید", reply_markup=markupt)
        bot.register_next_step_handler(message, amte)
def amte(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    user_temp_data[user_id]['amar3'] = message.text

    d = user_temp_data[user_id]
    if message.text == "🔁 بازگشت به منو":
        del user_temp_data[user_id]['amar3'] 
        ppname(message)
    elif message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['amar3']
        del user_temp_data[user_id]['magsd2']
        ppmabdawq2(message)
    else:

        markupt = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markupt.add('خير', 'بله', "↪️ باز گشت به مرحله قبل")

        bot.send_message(message.chat.id, "آیا دستور اکتشاف را تایید می کنید؟", reply_markup=markupt)
        bot.register_next_step_handler(message, ppersall)

def ppersall(message):
    user_id = message.from_user.id
    user_id2 = str(message.from_user.id)
    javab = message.text
    d = user_temp_data.get(user_id, {})
    if message.text == "↪️ باز گشت به مرحله قبل":
        del user_temp_data[user_id]['amar3']
        ppmagsdesdwe2(message)
    else:
        if javab == "بله":
            bot.send_message(CHANNEL_ID_2, f"آمار تیم اکتشاف {d['noae4']} «{user_data[user_id2]}» برای منطقه «{d['magsd2']}»\n «{d['amar3']}»")
            if nx.has_path(G, d['mbda2'], d['magsd2']):
                length = nx.shortest_path_length(G, source=d['mbda2'], target=d['magsd2'], weight='weight')
                #new_time = datetime.now() + timedelta(minutes=int(length))
                #d['zaman2'] = f"{new_time.hour:02}:{new_time.minute:02}"

                noae4 = d['noae4']
                if noae4 == "زمینی":
                    new_time = datetime.now() + timedelta(minutes=int(length))
                    d['zaman2'] = f"{new_time.hour:02}:{new_time.minute:02}"
                    photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-04_21-35-56.jpg')
                    icon = "🔱"
                elif noae4 == "دریایی":
                    new_time = datetime.now() + timedelta(minutes=(int(length)/2))
                    d['zaman2'] = f"{new_time.hour:02}:{new_time.minute:02}"
                    photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_13-06-21.jpg')
                    icon = "⚓️"
                elif noae4 == "هوایی":
                    new_time = datetime.now() + timedelta(minutes=(int(length)/3))
                    d['zaman2'] = f"{new_time.hour:02}:{new_time.minute:02}"
                    photo_path = os.path.join(script_dir, 'picther\\photo_2025-06-26_12-01-31.jpg')
                    icon = "🛰"
                else:
                    bot.send_message(message.chat.id, "نوع نیرو نامشخص است.")
                    del user_temp_data[user_id]
                    return

                caption_text = f"|{icon}|-تیم اکتشاف {noae4} «{user_data[user_id2]}» از «{d['mbda2']}» به طرف «{d['magsd2']}» حرکت کردند \n|⏳|-زمان رسیدن: {d['zaman2']}"
                with open(photo_path, 'rb') as photo:
                    bot.send_photo(CHANNEL_ID_1, photo, caption=caption_text)
                bot.send_message(message.chat.id, "✅ دستور اکتشاف با موفقیت ارسال شد")
                del user_temp_data[user_id]
                ppname2(message)
            else:
                bot.send_message(message.chat.id, "|‼️|-مسیری برای انتخاب شما وجود ندارد لطفا دوباره انتخاب نمایید")
                del user_temp_data[user_id]['amar3']
                del user_temp_data[user_id]['magsd2']
                del user_temp_data[user_id]['mbda2']
                ppnwet24(message)
        elif javab == "خیر":
            bot.send_message(message.chat.id, "✅ دستور اکتشاف لغو شد")
            del user_temp_data[user_id]
            ppname2(message)
def ppmap(message):
    nmp = message.text
    if message.text == "🔁 بازگشت به منو":
        ppname(message)
    else:
        if nmp == "قاره ۱":
            chat_id = message.chat.id
            photo_path = 'C:\\Users\\Amir mohamad\\Desktop\\maps\\map1.jpg'
            caption_text = f"«{nmp}»"
            with open(photo_path, 'rb') as photo:
                    bot.send_photo(chat_id, photo, caption=caption_text)
                    ppname2(message)
        elif nmp == "قاره ۲":
            chat_id = message.chat.id
            photo_path = 'C:\\Users\\Amir mohamad\\Desktop\\maps\\map2.jpg'
            caption_text = f"«{nmp}»"
            with open(photo_path, 'rb') as photo:
                    bot.send_photo(chat_id, photo, caption=caption_text)
                    ppname2(message)
        elif nmp == "قاره ۳":
            chat_id = message.chat.id
            photo_path = 'C:\\Users\\Amir mohamad\\Desktop\\maps\\map3.jpg'
            caption_text = f"«{nmp}»"
            with open(photo_path, 'rb') as photo:
                    bot.send_photo(chat_id, photo, caption=caption_text)
                    ppname2(message)
        elif nmp == "نقشه جهان":
            chat_id = message.chat.id
            photo_path = 'C:\\Users\\Amir mohamad\\Desktop\\maps\\allmap.jpg'
            caption_text = f"«{nmp}»"
            with open(photo_path, 'rb') as photo:
                    bot.send_photo(chat_id, photo, caption=caption_text)
                    ppname2(message)
        elif nmp == "نمای کلی سیاره":
            chat_id = message.chat.id
            photo_path = 'C:\\Users\\Amir mohamad\\Desktop\\maps\\planet map.jpg'
            caption_text = f"«{nmp}»"
            with open(photo_path, 'rb') as photo:
                    bot.send_photo(chat_id, photo, caption=caption_text)
                    ppname2(message)
if __name__ == '__main__':
    bot.polling()
